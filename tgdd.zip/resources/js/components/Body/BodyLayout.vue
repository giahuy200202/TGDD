<template>
    <div class="body-content">
        <img src="https://img.tgdd.vn/imgt/f_webp,fit_outside,quality_100/https://cdn.tgdd.vn/2023/06/banner/Banner-big-1920x450--3--1920x450-1.png"/>
    </div>
</template>

<script>
export default {
    data(){
        return {
            test: 0
        }
    }
};
</script>

<style>

.body-content{
    background-color: #f3f3f3;
}

</style>
